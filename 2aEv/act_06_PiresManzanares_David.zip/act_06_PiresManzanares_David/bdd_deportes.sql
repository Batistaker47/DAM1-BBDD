-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 30-01-2024 a las 09:50:05
-- Versión del servidor: 10.4.11-MariaDB
-- Versión de PHP: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `bdd_deportes`
--

DELIMITER $$
--
-- Procedimientos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `Deportes_Actualizar` (IN `id` INT, IN `nombre` VARCHAR(50))  UPDATE deportes SET
	dte_nombre = nombre
WHERE dte_id = id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Deportes_Borrar` (IN `id` INT)  DELETE FROM deportes
WHERE
	dte_id = id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Deportes_Buscar_Por_Id` (IN `id` INT)  SELECT * FROM deportes WHERE dte_id = id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Deportes_Buscar_Todo` ()  SELECT * FROM deportes ORDER BY dte_nombre$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Deportes_Deportistas_Actualizar` (IN `id_deportista` INT, IN `id_deporte` INT)  UPDATE deportes_deportistas SET
	dd_dep_id = id_deportista,
    dd_dte_id = id_deporte$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Deportes_Deportistas_Eliminar_Por_Deporte` (IN `id_deporte` INT)  DELETE FROM deportes_deportistas
WHERE
	dd_dte_id = id_deporte$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Deportes_Deportistas_Eliminar_Por_Deportista` (IN `id_deportista` INT)  NO SQL
    COMMENT 'Eliminar deportistas'
DELETE FROM deportes_deportistas
WHERE
	dd_dep_id = id_deportista$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Deportes_Deportistas_Insertar` (IN `id_deportista` INT, IN `id_deporte` INT)  INSERT INTO deportes_deportistas VALUES (id_deportista,id_deporte)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Deportes_Deportistas_Seleccionar_Por_Deporte_ID` (IN `id_deporte` INT)  SELECT * FROM deportes_deportistas
WHERE
	dd_dte_id = id_deporte$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Deportes_Deportistas_Seleccionar_Por_Deportista_ID` (IN `id_deportista` INT)  NO SQL
    COMMENT 'Seleccionar todo de deportes_deportistas por ID de deportista'
SELECT * FROM deportes_deportistas
WHERE
	dd_dep_id = id_deportista$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Deportes_Deportistas_Seleccionar_Todo` ()  SELECT * FROM deportes_deportistas$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Deportes_Filtrar` (IN `buscar` VARCHAR(50))  SELECT dte_nombre
FROM 
	deportes 
WHERE 
	dte_nombre LIKE buscar$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Deportes_Insertar` (IN `nombre` VARCHAR(50))  INSERT INTO deportes VALUES (null,nombre)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Deportistas_Actualizar` (IN `id` INT, IN `nombre` VARCHAR(50), IN `apellidos` VARCHAR(50))  UPDATE deportistas SET
dep_nombre = nombre,
dep_apellidos = apellidos
WHERE
	dep_id = id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Deportistas_Buscar_Por_Id` (IN `id` INT)  SELECT * FROM deportistas
WHERE
	dep_id = id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Deportistas_Buscar_Todo` ()  SELECT * FROM deportistas ORDER BY dep_nombre$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Deportistas_Eliminar` (IN `id` INT)  DELETE FROM deportistas
WHERE
	dep_id = id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Deportistas_Filtrar` (IN `buscar` VARCHAR(50))  SELECT *
FROM deportistas
WHERE
	dep_nombre LIKE buscar$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Deportistas_Insertar` (IN `nombre` VARCHAR(50), IN `apellidos` VARCHAR(50))  INSERT INTO deportistas VALUES
(null, nombre, apellidos)$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `deportes`
--

CREATE TABLE `deportes` (
  `dte_id` int(11) NOT NULL,
  `dte_nombre` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `deportes`
--

INSERT INTO `deportes` (`dte_id`, `dte_nombre`) VALUES
(1, 'Futbol'),
(2, 'Baloncesto'),
(3, 'Beisbol'),
(4, 'Golf'),
(5, 'Boxeo'),
(6, 'F1'),
(7, 'PingPong'),
(8, 'Natacion'),
(9, 'Atletismo'),
(10, 'Rugby');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `deportes_deportistas`
--

CREATE TABLE `deportes_deportistas` (
  `dd_dep_id` int(11) NOT NULL,
  `dd_dte_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `deportes_deportistas`
--

INSERT INTO `deportes_deportistas` (`dd_dep_id`, `dd_dte_id`) VALUES
(1, 2),
(1, 3),
(3, 3),
(4, 5),
(4, 7),
(5, 10),
(7, 2),
(7, 4),
(8, 1),
(10, 5),
(11, 1),
(11, 5),
(12, 4),
(16, 3),
(17, 2),
(18, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `deportistas`
--

CREATE TABLE `deportistas` (
  `dep_id` int(11) NOT NULL,
  `dep_nombre` varchar(50) NOT NULL,
  `dep_apellidos` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `deportistas`
--

INSERT INTO `deportistas` (`dep_id`, `dep_nombre`, `dep_apellidos`) VALUES
(1, 'Ashli', 'McGillivrie'),
(2, 'Jaimie', 'Chell'),
(3, 'Hartwell', 'Rolley'),
(4, 'Cherie', 'Senner'),
(5, 'Mortimer', 'Toulson'),
(6, 'Ophelie', 'Peckitt'),
(7, 'Helge', 'Lough'),
(8, 'Phyllis', 'Kibard'),
(9, 'Sidonia', 'Kosiada'),
(10, 'Shoshana', 'Wimpey'),
(11, 'Jesselyn', 'Giacomuzzo'),
(12, 'Crosby', 'Bartkiewicz'),
(13, 'Jackqueline', 'Quinane'),
(14, 'Trstram', 'Ehlerding'),
(15, 'Hadley', 'Mathewson'),
(16, 'Maurizio', 'Glazier'),
(17, 'Bernadette', 'Fettis'),
(18, 'Natasha', 'Beernt'),
(19, 'Granville', 'Mingotti'),
(20, 'Lianna', 'Hannaby'),
(21, 'Rutherford', 'Restall'),
(22, 'Chrisse', 'Jaegar'),
(23, 'Sharon', 'Wyndham'),
(24, 'Obie', 'MacCall'),
(25, 'Richie', 'Vockins'),
(26, 'Gonzalo', 'Winsor'),
(27, 'Scott', 'MacGray'),
(28, 'Danny', 'Tenant'),
(29, 'Bryana', 'Fieldgate'),
(30, 'Theresita', 'Donan'),
(31, 'Deerdre', 'Notton'),
(32, 'Valentia', 'Ligertwood'),
(33, 'Lauree', 'Duer'),
(34, 'Bent', 'Pengilly'),
(35, 'Adelbert', 'Colnet'),
(36, 'Janine', 'Kershow'),
(37, 'Arvy', 'Snoddon'),
(38, 'Kimbra', 'Schubart'),
(39, 'Nikolaos', 'Counter'),
(40, 'Claire', 'Bastick'),
(41, 'Jenni', 'Kittredge'),
(42, 'Jocko', 'Scough'),
(43, 'Maggy', 'Pauleau'),
(44, 'Mariya', 'Sterrick'),
(45, 'Emmett', 'Derrett'),
(46, 'Katina', 'Exrol'),
(47, 'Courtnay', 'Byrnes'),
(48, 'Heall', 'Chew'),
(49, 'Gaynor', 'Crenshaw'),
(50, 'Elissa', 'Leele');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `deportes`
--
ALTER TABLE `deportes`
  ADD PRIMARY KEY (`dte_id`);

--
-- Indices de la tabla `deportes_deportistas`
--
ALTER TABLE `deportes_deportistas`
  ADD PRIMARY KEY (`dd_dep_id`,`dd_dte_id`),
  ADD KEY `deportes_deportes_deportistas` (`dd_dte_id`);

--
-- Indices de la tabla `deportistas`
--
ALTER TABLE `deportistas`
  ADD PRIMARY KEY (`dep_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `deportes`
--
ALTER TABLE `deportes`
  MODIFY `dte_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `deportistas`
--
ALTER TABLE `deportistas`
  MODIFY `dep_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `deportes_deportistas`
--
ALTER TABLE `deportes_deportistas`
  ADD CONSTRAINT `deportes_deportes_deportistas` FOREIGN KEY (`dd_dte_id`) REFERENCES `deportes` (`dte_id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `deportistas_deportes_deportistas` FOREIGN KEY (`dd_dep_id`) REFERENCES `deportistas` (`dep_id`) ON DELETE NO ACTION ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
